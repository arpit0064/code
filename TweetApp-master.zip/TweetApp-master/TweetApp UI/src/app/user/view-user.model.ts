export class ViewUser{
    constructor(public emailId: string,
        public dateOfBirth: Date,
        public gender: string,
        public firstName: string,
        public lastName: string){
    }
}